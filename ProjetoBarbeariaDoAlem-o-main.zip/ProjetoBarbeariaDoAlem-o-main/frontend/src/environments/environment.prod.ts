export const environment = {
  production: true,
  apiUrl: 'https://barbearia-do-alem-backend.onrender.com/api'
};